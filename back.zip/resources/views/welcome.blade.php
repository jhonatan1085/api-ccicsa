<!DOCTYPE html>
<html lang="es" data-critters-container>

<head>
    <meta charset="utf-8">
    <title>CCICSA PERU</title>
    <base href="/">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <!-- <link rel="preconnect" href="https://fonts.gstatic.com"> -->
    <!-- <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->
    <style>
        @import"https://cdn.jsdelivr.net/npm/lightgallery@2.0.0-beta.4/css/lightgallery.css";
        @import"https://cdn.jsdelivr.net/npm/lightgallery@2.0.0-beta.4/css/lg-zoom.css";
        @import"https://cdn.jsdelivr.net/npm/lightgallery@2.0.0-beta.4/css/lg-thumbnail.css";
        @import"https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600";

        :root {
            --bs-blue: #0d6efd;
            --bs-indigo: #6610f2;
            --bs-purple: #6f42c1;
            --bs-pink: #d63384;
            --bs-red: #dc3545;
            --bs-orange: #fd7e14;
            --bs-yellow: #ffc107;
            --bs-green: #198754;
            --bs-teal: #20c997;
            --bs-cyan: #0dcaf0;
            --bs-black: #000;
            --bs-white: #fff;
            --bs-gray: #6c757d;
            --bs-gray-dark: #343a40;
            --bs-gray-100: #f8f9fa;
            --bs-gray-200: #e9ecef;
            --bs-gray-300: #dee2e6;
            --bs-gray-400: #ced4da;
            --bs-gray-500: #adb5bd;
            --bs-gray-600: #6c757d;
            --bs-gray-700: #495057;
            --bs-gray-800: #343a40;
            --bs-gray-900: #212529;
            --bs-primary: #0d6efd;
            --bs-secondary: #6c757d;
            --bs-success: #198754;
            --bs-info: #0dcaf0;
            --bs-warning: #ffc107;
            --bs-danger: #dc3545;
            --bs-light: #f8f9fa;
            --bs-dark: #212529;
            --bs-primary-rgb: 13, 110, 253;
            --bs-secondary-rgb: 108, 117, 125;
            --bs-success-rgb: 25, 135, 84;
            --bs-info-rgb: 13, 202, 240;
            --bs-warning-rgb: 255, 193, 7;
            --bs-danger-rgb: 220, 53, 69;
            --bs-light-rgb: 248, 249, 250;
            --bs-dark-rgb: 33, 37, 41;
            --bs-primary-text-emphasis: #052c65;
            --bs-secondary-text-emphasis: #2b2f32;
            --bs-success-text-emphasis: #0a3622;
            --bs-info-text-emphasis: #055160;
            --bs-warning-text-emphasis: #664d03;
            --bs-danger-text-emphasis: #58151c;
            --bs-light-text-emphasis: #495057;
            --bs-dark-text-emphasis: #495057;
            --bs-primary-bg-subtle: #cfe2ff;
            --bs-secondary-bg-subtle: #e2e3e5;
            --bs-success-bg-subtle: #d1e7dd;
            --bs-info-bg-subtle: #cff4fc;
            --bs-warning-bg-subtle: #fff3cd;
            --bs-danger-bg-subtle: #f8d7da;
            --bs-light-bg-subtle: #fcfcfd;
            --bs-dark-bg-subtle: #ced4da;
            --bs-primary-border-subtle: #9ec5fe;
            --bs-secondary-border-subtle: #c4c8cb;
            --bs-success-border-subtle: #a3cfbb;
            --bs-info-border-subtle: #9eeaf9;
            --bs-warning-border-subtle: #ffe69c;
            --bs-danger-border-subtle: #f1aeb5;
            --bs-light-border-subtle: #e9ecef;
            --bs-dark-border-subtle: #adb5bd;
            --bs-white-rgb: 255, 255, 255;
            --bs-black-rgb: 0, 0, 0;
            --bs-font-sans-serif: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", "Noto Sans", "Liberation Sans", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
            --bs-font-monospace: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
            --bs-gradient: linear-gradient(180deg, rgba(255, 255, 255, .15), rgba(255, 255, 255, 0));
            --bs-body-font-family: var(--bs-font-sans-serif);
            --bs-body-font-size: 1rem;
            --bs-body-font-weight: 400;
            --bs-body-line-height: 1.5;
            --bs-body-color: #212529;
            --bs-body-color-rgb: 33, 37, 41;
            --bs-body-bg: #fff;
            --bs-body-bg-rgb: 255, 255, 255;
            --bs-emphasis-color: #000;
            --bs-emphasis-color-rgb: 0, 0, 0;
            --bs-secondary-color: rgba(33, 37, 41, .75);
            --bs-secondary-color-rgb: 33, 37, 41;
            --bs-secondary-bg: #e9ecef;
            --bs-secondary-bg-rgb: 233, 236, 239;
            --bs-tertiary-color: rgba(33, 37, 41, .5);
            --bs-tertiary-color-rgb: 33, 37, 41;
            --bs-tertiary-bg: #f8f9fa;
            --bs-tertiary-bg-rgb: 248, 249, 250;
            --bs-heading-color: inherit;
            --bs-link-color: #0d6efd;
            --bs-link-color-rgb: 13, 110, 253;
            --bs-link-decoration: underline;
            --bs-link-hover-color: #0a58ca;
            --bs-link-hover-color-rgb: 10, 88, 202;
            --bs-code-color: #d63384;
            --bs-highlight-color: #212529;
            --bs-highlight-bg: #fff3cd;
            --bs-border-width: 1px;
            --bs-border-style: solid;
            --bs-border-color: #dee2e6;
            --bs-border-color-translucent: rgba(0, 0, 0, .175);
            --bs-border-radius: .375rem;
            --bs-border-radius-sm: .25rem;
            --bs-border-radius-lg: .5rem;
            --bs-border-radius-xl: 1rem;
            --bs-border-radius-xxl: 2rem;
            --bs-border-radius-2xl: var(--bs-border-radius-xxl);
            --bs-border-radius-pill: 50rem;
            --bs-box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .15);
            --bs-box-shadow-sm: 0 .125rem .25rem rgba(0, 0, 0, .075);
            --bs-box-shadow-lg: 0 1rem 3rem rgba(0, 0, 0, .175);
            --bs-box-shadow-inset: inset 0 1px 2px rgba(0, 0, 0, .075);
            --bs-focus-ring-width: .25rem;
            --bs-focus-ring-opacity: .25;
            --bs-focus-ring-color: rgba(13, 110, 253, .25);
            --bs-form-valid-color: #198754;
            --bs-form-valid-border-color: #198754;
            --bs-form-invalid-color: #dc3545;
            --bs-form-invalid-border-color: #dc3545
        }

        *,
        *:before,
        *:after {
            box-sizing: border-box
        }

        @media (prefers-reduced-motion: no-preference) {
            :root {
                scroll-behavior: smooth
            }
        }

        body {
            margin: 0;
            font-family: var(--bs-body-font-family);
            font-size: var(--bs-body-font-size);
            font-weight: var(--bs-body-font-weight);
            line-height: var(--bs-body-line-height);
            color: var(--bs-body-color);
            text-align: var(--bs-body-text-align);
            background-color: var(--bs-body-bg);
            -webkit-text-size-adjust: 100%;
            -webkit-tap-highlight-color: rgba(0, 0, 0, 0)
        }

        :root {
            --bs-breakpoint-xs: 0;
            --bs-breakpoint-sm: 576px;
            --bs-breakpoint-md: 768px;
            --bs-breakpoint-lg: 992px;
            --bs-breakpoint-xl: 1200px;
            --bs-breakpoint-xxl: 1400px
        }

        @charset "UTF-8";

        :root {
            --fa-font-brands: normal 400 1em/1 "Font Awesome 6 Brands"
        }

        @font-face {
            font-family: "Font Awesome 6 Brands";
            font-style: normal;
            font-weight: 400;
            font-display: block;
            src: url(fa-brands-400.859fc3887485de84.woff2) format("woff2"), url(fa-brands-400.7fa789ab57acb632.ttf) format("truetype")
        }

        :root {
            --fa-font-regular: normal 400 1em/1 "Font Awesome 6 Free"
        }

        @font-face {
            font-family: "Font Awesome 6 Free";
            font-style: normal;
            font-weight: 400;
            font-display: block;
            src: url(fa-regular-400.2ffd018f0eda6f7b.woff2) format("woff2"), url(fa-regular-400.da02cb7e372f16a2.ttf) format("truetype")
        }

        :root {
            --fa-font-solid: normal 900 1em/1 "Font Awesome 6 Free"
        }

        @font-face {
            font-family: "Font Awesome 6 Free";
            font-style: normal;
            font-weight: 900;
            font-display: block;
            src: url(fa-solid-900.40ddefd79fe7af45.woff2) format("woff2"), url(fa-solid-900.3a463ec33b4fe9f7.ttf) format("truetype")
        }

        html {
            --mat-option-selected-state-label-text-color: #3f51b5;
            --mat-option-label-text-color: rgba(0, 0, 0, .87);
            --mat-option-hover-state-layer-color: rgba(0, 0, 0, .04);
            --mat-option-focus-state-layer-color: rgba(0, 0, 0, .04);
            --mat-option-selected-state-layer-color: rgba(0, 0, 0, .04)
        }

        html {
            --mat-optgroup-label-text-color: rgba(0, 0, 0, .87)
        }

        html {
            --mdc-filled-text-field-caret-color: #3f51b5;
            --mdc-filled-text-field-focus-active-indicator-color: #3f51b5;
            --mdc-filled-text-field-focus-label-text-color: rgba(63, 81, 181, .87);
            --mdc-filled-text-field-container-color: whitesmoke;
            --mdc-filled-text-field-disabled-container-color: #fafafa;
            --mdc-filled-text-field-label-text-color: rgba(0, 0, 0, .6);
            --mdc-filled-text-field-disabled-label-text-color: rgba(0, 0, 0, .38);
            --mdc-filled-text-field-input-text-color: rgba(0, 0, 0, .87);
            --mdc-filled-text-field-disabled-input-text-color: rgba(0, 0, 0, .38);
            --mdc-filled-text-field-input-text-placeholder-color: rgba(0, 0, 0, .6);
            --mdc-filled-text-field-error-focus-label-text-color: #f44336;
            --mdc-filled-text-field-error-label-text-color: #f44336;
            --mdc-filled-text-field-error-caret-color: #f44336;
            --mdc-filled-text-field-active-indicator-color: rgba(0, 0, 0, .42);
            --mdc-filled-text-field-disabled-active-indicator-color: rgba(0, 0, 0, .06);
            --mdc-filled-text-field-hover-active-indicator-color: rgba(0, 0, 0, .87);
            --mdc-filled-text-field-error-active-indicator-color: #f44336;
            --mdc-filled-text-field-error-focus-active-indicator-color: #f44336;
            --mdc-filled-text-field-error-hover-active-indicator-color: #f44336;
            --mdc-outlined-text-field-caret-color: #3f51b5;
            --mdc-outlined-text-field-focus-outline-color: #3f51b5;
            --mdc-outlined-text-field-focus-label-text-color: rgba(63, 81, 181, .87);
            --mdc-outlined-text-field-label-text-color: rgba(0, 0, 0, .6);
            --mdc-outlined-text-field-disabled-label-text-color: rgba(0, 0, 0, .38);
            --mdc-outlined-text-field-input-text-color: rgba(0, 0, 0, .87);
            --mdc-outlined-text-field-disabled-input-text-color: rgba(0, 0, 0, .38);
            --mdc-outlined-text-field-input-text-placeholder-color: rgba(0, 0, 0, .6);
            --mdc-outlined-text-field-error-caret-color: #f44336;
            --mdc-outlined-text-field-error-focus-label-text-color: #f44336;
            --mdc-outlined-text-field-error-label-text-color: #f44336;
            --mdc-outlined-text-field-outline-color: rgba(0, 0, 0, .38);
            --mdc-outlined-text-field-disabled-outline-color: rgba(0, 0, 0, .06);
            --mdc-outlined-text-field-hover-outline-color: rgba(0, 0, 0, .87);
            --mdc-outlined-text-field-error-focus-outline-color: #f44336;
            --mdc-outlined-text-field-error-hover-outline-color: #f44336;
            --mdc-outlined-text-field-error-outline-color: #f44336;
            --mat-form-field-disabled-input-text-placeholder-color: rgba(0, 0, 0, .38)
        }

        html {
            --mat-select-panel-background-color: white;
            --mat-select-enabled-trigger-text-color: rgba(0, 0, 0, .87);
            --mat-select-disabled-trigger-text-color: rgba(0, 0, 0, .38);
            --mat-select-placeholder-text-color: rgba(0, 0, 0, .6);
            --mat-select-enabled-arrow-color: rgba(0, 0, 0, .54);
            --mat-select-disabled-arrow-color: rgba(0, 0, 0, .38);
            --mat-select-focused-arrow-color: rgba(63, 81, 181, .87);
            --mat-select-invalid-arrow-color: rgba(244, 67, 54, .87)
        }

        html {
            --mat-autocomplete-background-color: white
        }

        html {
            --mat-menu-item-label-text-color: rgba(0, 0, 0, .87);
            --mat-menu-item-icon-color: rgba(0, 0, 0, .87);
            --mat-menu-item-hover-state-layer-color: rgba(0, 0, 0, .04);
            --mat-menu-item-focus-state-layer-color: rgba(0, 0, 0, .04);
            --mat-menu-container-color: white
        }

        html {
            --mat-paginator-container-text-color: rgba(0, 0, 0, .87);
            --mat-paginator-container-background-color: white;
            --mat-paginator-enabled-icon-color: rgba(0, 0, 0, .54);
            --mat-paginator-disabled-icon-color: rgba(0, 0, 0, .12)
        }

        html {
            --mat-paginator-container-size: 56px
        }

        html {
            --mdc-checkbox-disabled-selected-icon-color: rgba(0, 0, 0, .38);
            --mdc-checkbox-disabled-unselected-icon-color: rgba(0, 0, 0, .38);
            --mdc-checkbox-selected-checkmark-color: #fff;
            --mdc-checkbox-selected-focus-icon-color: #ff4081;
            --mdc-checkbox-selected-hover-icon-color: #ff4081;
            --mdc-checkbox-selected-icon-color: #ff4081;
            --mdc-checkbox-selected-pressed-icon-color: #ff4081;
            --mdc-checkbox-unselected-focus-icon-color: #212121;
            --mdc-checkbox-unselected-hover-icon-color: #212121;
            --mdc-checkbox-unselected-icon-color: rgba(0, 0, 0, .54);
            --mdc-checkbox-unselected-pressed-icon-color: rgba(0, 0, 0, .54);
            --mdc-checkbox-selected-focus-state-layer-color: #ff4081;
            --mdc-checkbox-selected-hover-state-layer-color: #ff4081;
            --mdc-checkbox-selected-pressed-state-layer-color: #ff4081;
            --mdc-checkbox-unselected-focus-state-layer-color: black;
            --mdc-checkbox-unselected-hover-state-layer-color: black;
            --mdc-checkbox-unselected-pressed-state-layer-color: black
        }

        html {
            --mdc-checkbox-state-layer-size: 40px
        }

        html {
            --mat-table-background-color: white;
            --mat-table-header-headline-color: rgba(0, 0, 0, .87);
            --mat-table-row-item-label-text-color: rgba(0, 0, 0, .87);
            --mat-table-row-item-outline-color: rgba(0, 0, 0, .12)
        }

        html {
            --mat-table-header-container-height: 56px;
            --mat-table-footer-container-height: 52px;
            --mat-table-row-item-container-height: 52px
        }

        html {
            --mat-badge-background-color: #3f51b5;
            --mat-badge-text-color: white;
            --mat-badge-disabled-state-background-color: #b9b9b9;
            --mat-badge-disabled-state-text-color: rgba(0, 0, 0, .38)
        }

        html {
            --mat-bottom-sheet-container-text-color: rgba(0, 0, 0, .87);
            --mat-bottom-sheet-container-background-color: white
        }

        html {
            --mat-legacy-button-toggle-text-color: rgba(0, 0, 0, .38);
            --mat-legacy-button-toggle-state-layer-color: rgba(0, 0, 0, .12);
            --mat-legacy-button-toggle-selected-state-text-color: rgba(0, 0, 0, .54);
            --mat-legacy-button-toggle-selected-state-background-color: #e0e0e0;
            --mat-legacy-button-toggle-disabled-state-text-color: rgba(0, 0, 0, .26);
            --mat-legacy-button-toggle-disabled-state-background-color: #eeeeee;
            --mat-legacy-button-toggle-disabled-selected-state-background-color: #bdbdbd;
            --mat-standard-button-toggle-text-color: rgba(0, 0, 0, .87);
            --mat-standard-button-toggle-background-color: white;
            --mat-standard-button-toggle-state-layer-color: black;
            --mat-standard-button-toggle-selected-state-background-color: #e0e0e0;
            --mat-standard-button-toggle-selected-state-text-color: rgba(0, 0, 0, .87);
            --mat-standard-button-toggle-disabled-state-text-color: rgba(0, 0, 0, .26);
            --mat-standard-button-toggle-disabled-state-background-color: white;
            --mat-standard-button-toggle-disabled-selected-state-text-color: rgba(0, 0, 0, .87);
            --mat-standard-button-toggle-disabled-selected-state-background-color: #bdbdbd;
            --mat-standard-button-toggle-divider-color: #e0e0e0
        }

        html {
            --mat-standard-button-toggle-height: 48px
        }

        html {
            --mat-datepicker-calendar-date-selected-state-text-color: white;
            --mat-datepicker-calendar-date-selected-state-background-color: #3f51b5;
            --mat-datepicker-calendar-date-selected-disabled-state-background-color: rgba(63, 81, 181, .4);
            --mat-datepicker-calendar-date-today-selected-state-outline-color: white;
            --mat-datepicker-calendar-date-focus-state-background-color: rgba(63, 81, 181, .3);
            --mat-datepicker-calendar-date-hover-state-background-color: rgba(63, 81, 181, .3);
            --mat-datepicker-toggle-active-state-icon-color: #3f51b5;
            --mat-datepicker-calendar-date-in-range-state-background-color: rgba(63, 81, 181, .2);
            --mat-datepicker-calendar-date-in-comparison-range-state-background-color: rgba(249, 171, 0, .2);
            --mat-datepicker-calendar-date-in-overlap-range-state-background-color: #a8dab5;
            --mat-datepicker-calendar-date-in-overlap-range-selected-state-background-color: #46a35e;
            --mat-datepicker-toggle-icon-color: rgba(0, 0, 0, .54);
            --mat-datepicker-calendar-body-label-text-color: rgba(0, 0, 0, .54);
            --mat-datepicker-calendar-period-button-icon-color: rgba(0, 0, 0, .54);
            --mat-datepicker-calendar-navigation-button-icon-color: rgba(0, 0, 0, .54);
            --mat-datepicker-calendar-header-divider-color: rgba(0, 0, 0, .12);
            --mat-datepicker-calendar-header-text-color: rgba(0, 0, 0, .54);
            --mat-datepicker-calendar-date-today-outline-color: rgba(0, 0, 0, .38);
            --mat-datepicker-calendar-date-today-disabled-state-outline-color: rgba(0, 0, 0, .18);
            --mat-datepicker-calendar-date-text-color: rgba(0, 0, 0, .87);
            --mat-datepicker-calendar-date-outline-color: transparent;
            --mat-datepicker-calendar-date-disabled-state-text-color: rgba(0, 0, 0, .38);
            --mat-datepicker-calendar-date-preview-state-outline-color: rgba(0, 0, 0, .24);
            --mat-datepicker-range-input-separator-color: rgba(0, 0, 0, .87);
            --mat-datepicker-range-input-disabled-state-separator-color: rgba(0, 0, 0, .38);
            --mat-datepicker-range-input-disabled-state-text-color: rgba(0, 0, 0, .38);
            --mat-datepicker-calendar-container-background-color: white;
            --mat-datepicker-calendar-container-text-color: rgba(0, 0, 0, .87)
        }

        html {
            --mat-divider-color: rgba(0, 0, 0, .12)
        }

        html {
            --mat-expansion-container-background-color: white;
            --mat-expansion-container-text-color: rgba(0, 0, 0, .87);
            --mat-expansion-actions-divider-color: rgba(0, 0, 0, .12);
            --mat-expansion-header-hover-state-layer-color: rgba(0, 0, 0, .04);
            --mat-expansion-header-focus-state-layer-color: rgba(0, 0, 0, .04);
            --mat-expansion-header-disabled-state-text-color: rgba(0, 0, 0, .26);
            --mat-expansion-header-text-color: rgba(0, 0, 0, .87);
            --mat-expansion-header-description-color: rgba(0, 0, 0, .54);
            --mat-expansion-header-indicator-color: rgba(0, 0, 0, .54)
        }

        html {
            --mat-expansion-header-collapsed-state-height: 48px;
            --mat-expansion-header-expanded-state-height: 64px
        }

        html {
            --mat-icon-color: inherit
        }

        html {
            --mat-sidenav-container-divider-color: rgba(0, 0, 0, .12);
            --mat-sidenav-container-background-color: white;
            --mat-sidenav-container-text-color: rgba(0, 0, 0, .87);
            --mat-sidenav-content-background-color: #fafafa;
            --mat-sidenav-content-text-color: rgba(0, 0, 0, .87);
            --mat-sidenav-scrim-color: rgba(0, 0, 0, .6)
        }

        html {
            --mat-stepper-header-icon-foreground-color: white;
            --mat-stepper-header-selected-state-icon-background-color: #3f51b5;
            --mat-stepper-header-selected-state-icon-foreground-color: white;
            --mat-stepper-header-done-state-icon-background-color: #3f51b5;
            --mat-stepper-header-done-state-icon-foreground-color: white;
            --mat-stepper-header-edit-state-icon-background-color: #3f51b5;
            --mat-stepper-header-edit-state-icon-foreground-color: white;
            --mat-stepper-container-color: white;
            --mat-stepper-line-color: rgba(0, 0, 0, .12);
            --mat-stepper-header-hover-state-layer-color: rgba(0, 0, 0, .04);
            --mat-stepper-header-focus-state-layer-color: rgba(0, 0, 0, .04);
            --mat-stepper-header-label-text-color: rgba(0, 0, 0, .54);
            --mat-stepper-header-optional-label-text-color: rgba(0, 0, 0, .54);
            --mat-stepper-header-selected-state-label-text-color: rgba(0, 0, 0, .87);
            --mat-stepper-header-error-state-label-text-color: #f44336;
            --mat-stepper-header-icon-background-color: rgba(0, 0, 0, .54);
            --mat-stepper-header-error-state-icon-foreground-color: #f44336;
            --mat-stepper-header-error-state-icon-background-color: transparent
        }

        html {
            --mat-stepper-header-height: 72px
        }

        html {
            --mat-toolbar-container-background-color: whitesmoke;
            --mat-toolbar-container-text-color: rgba(0, 0, 0, .87)
        }

        html {
            --mat-toolbar-standard-height: 64px;
            --mat-toolbar-mobile-height: 56px
        }

        html {
            height: 100%
        }

        body {
            font-family: Poppins, sans-serif;
            font-size: 16px;
            color: #333448;
            background: linear-gradient(0deg, rgba(51, 53, 72, .05), rgba(51, 53, 72, .05)), #ffffff;
            overflow-x: hidden;
            height: 100%
        }
    </style>
    <link rel="stylesheet" href="styles.32efaca87a00faf2.css" media="print" onload="this.media='all'"><noscript>
        <link rel="stylesheet" href="styles.32efaca87a00faf2.css">
    </noscript>
</head>

<body>
    <app-root></app-root>
    <script src="runtime.23d641ed444bb624.js" type="module"></script>
    <script src="polyfills.e3550c73c66b1b00.js" type="module"></script>
    <script src="scripts.5082b8320b33a294.js" defer></script>
    <script src="main.19e3712a1731f7f2.js" type="module"></script>
</body>

</html>